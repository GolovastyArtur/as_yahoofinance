﻿.. include:: ../Includes.txt
.. include:: Images.txt

.. _tutorial:

Tutorial
========

#. Install the Extension.

#. Include the TypoScript from as\_yahoofinance.
    |img-ts|
#. Create a page content of the type plugin. Choose AS Yahoo Plugin.
    |img-plugin|
#. Enter chart parameters.
    |img-plugin-settings1|
    |img-plugin-settings2|
#. Finish.
    |img-finish|


