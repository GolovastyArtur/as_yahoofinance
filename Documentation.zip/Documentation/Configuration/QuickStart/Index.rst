﻿.. include:: ../../Includes.txt

Quick Start
^^^^^^^^^^^

- Include the TypoScript from the extension.

- Create a frontend plugin and choose AS YahooFinance Plugin.

- Fill in the name of the index

