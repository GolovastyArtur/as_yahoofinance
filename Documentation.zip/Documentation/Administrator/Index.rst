﻿.. include:: ../Includes.txt


.. _admin-manual:

Administrator Manual
====================

- Fields are listed in the section “Users manual”.

- You can configure via TypoScript how width and height from chartdiv.