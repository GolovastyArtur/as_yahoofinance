﻿.. include:: ../Includes.txt

.. _known-problems:

Known Problems
==============

- None so far.

- If you've found some, please contact me or visit `TYPO3 Forge
  <http://forge.typo3.org/projects/show/extension-as_yahoofinance>`_



